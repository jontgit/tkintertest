
class Script():
    def __init__(self, remote_connection):
        self.remote_connection = remote_connection
        self.title = "Prompt Prio State"
        self.description = ""
        self.device = ""
        self.base_script = """
send_command("conf t")
send_command("prompt hostname priority state")
send_command("exit")
send_command("wr")


"""

    def run(self):
        
        self.remote_connection.send_command("conf t")
        self.remote_connection.send_command("prompt hostname priority state")
        self.remote_connection.send_command("exit")
        self.remote_connection.send_command("wr")
        
        
        


        vars = locals()
        if "return_data" in vars.keys():
            return vars["return_data"]
        