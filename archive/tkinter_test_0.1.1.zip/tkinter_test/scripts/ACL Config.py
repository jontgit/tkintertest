
class Script():
    def __init__(self, remote_connection):
        self.remote_connection = remote_connection
        self.title = "ACL Config"
        self.description = "Do some rapid ACL Changes"
        self.device = "Cisco ASA"
        self.base_script = """send_command("conf t")
send_command("object-group network logic.monitor")
send_command("network-object 46.37.179.0 255.255.255.240")
send_command("network-object 81.201.138.160 255.255.255.240")
send_command("object-group service logic.monitor.tcp tcp")
send_command("port-object eq 5986")
send_command("access-list acl_out line 1 extended permit tcp object-group logic.monitor any object-group logic.monitor.tcp")

"""

    def run(self):
        self.remote_connection.send_command("conf t")
        self.remote_connection.send_command("object-group network logic.monitor")
        self.remote_connection.send_command("network-object 46.37.179.0 255.255.255.240")
        self.remote_connection.send_command("network-object 81.201.138.160 255.255.255.240")
        self.remote_connection.send_command("object-group service logic.monitor.tcp tcp")
        self.remote_connection.send_command("port-object eq 5986")
        self.remote_connection.send_command("access-list acl_out line 1 extended permit tcp object-group logic.monitor any object-group logic.monitor.tcp")
        
        


        vars = locals()
        del(vars["self"])
        return vars
        