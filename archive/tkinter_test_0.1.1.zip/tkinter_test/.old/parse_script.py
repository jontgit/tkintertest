

def parse_script(input_file):
    pass