
from tkinter import *

import csv
from getpass import getpass
from time import sleep
from threading import Thread
from queue import Queue
from netmiko import (
    ConnectHandler,
    NetmikoTimeoutException,
    NetmikoAuthenticationException,
)

CONCURRENT_SSH_LIMIT = 5
DATA_FILE = "man4_new.csv"

class RemoteConnection():

    def __init__(self, job):
        
        self.read_job_data(job)  # Read Job data first
        self.connect_to_device() # Connect to the device next
        self.run_script()        # The main commands are issued via this function
        self.logout()

    def read_job_data(self, job):
        # associates all relevant data for job with RemoteConnection
        self.hostname = job['hostname']
        self.username = job['username']
        self.password = job['password']
        self.device_type = job['device_type']
        self.additional_data = job['additional_data']

        self.status = "running"
        self.config = False

    def connect_to_device(self):
        self.device = {
            "device_type": self.device_type,
            "host": self.hostname,
            "username": self.username,
            "password": self.password,
            "secret": self.password,
            "session_log": f"./logs/{self.hostname}.log",
        }

        try:
            self.remote_connection = ConnectHandler(**self.device)
            self.remote_connection.enable()
            
        except (NetmikoTimeoutException, NetmikoAuthenticationException) as error:
            print(error)
            self.status = "failed"
            exit()

    def logout(self):
        self.remote_connection.disconnect()
        self.status = "complete"

    def send_command(self, command) -> str:
        
        if self.config:
            if command == 'end':
                self.config = False
            
            response = self.remote_connection.send_command(command, expect_string='.*#', read_timeout=10)

        else:
            if command in ['conf t', 'configure t', 'configure terminal']:
                self.config = True
                response = self.remote_connection.send_command(command, expect_string='.*#', read_timeout=10)
            else:

                response = self.remote_connection.send_command(command, read_timeout=10)



        return response

    def run_script(self):

        pass

class WorkerThread(Thread):
    def __init__(self, work_queue, complete_queue):

        Thread.__init__(self)
        self.daemon = True
        self.work_queue = work_queue
        self.complete_queue = complete_queue

    def run(self):
        while True:
            if not self.work_queue.empty():
                job = self.work_queue.get()
                remote_connection = RemoteConnection(job)
                if remote_connection.status != 'running':
                    self.work_queue.task_done()
                    self.complete_queue.put(job)

class ManagerThread(Thread):
    def __init__(self, manager_queue, complete_queue):
        Thread.__init__(self)
        self.daemon = True
        self.manager_queue = manager_queue
        self.complete_queue = complete_queue
        self.work_queue = Queue(maxsize=CONCURRENT_SSH_LIMIT)
        self.worker_threads = []
        for i in range(CONCURRENT_SSH_LIMIT):
            self.worker_threads.append(WorkerThread(self.work_queue, complete_queue).start())

    def run(self):
        while True:
            if not self.manager_queue.empty():
                if not self.work_queue.full():
                    self.work_queue.put(self.manager_queue.get())
            sleep(0.1)

def parse_input_data() -> list:
    devices = []
    data = csv.DictReader(open(DATA_FILE))
    for line in data:
        devices.append({
            'hostname' : line["DisplayName"],
            'complete' : False if line["Complete"] == "False" else True,
            'additional_data' : {
            "k9_image" : False if line["k9_image"] == "False" else True
                }
            }
        )
    return devices

def load_file() -> dict:
    return csv.DictReader(open(DATA_FILE))

def write_file(input):
    with open("man4_new.csv", 'w') as write_file:
        write_file.write('DisplayName,Complete,k9_image\n')
        for line in input:
            write_file.write(f"{line['hostname']},{line['complete']},{line['additional_data']['k9_image']}\n")


if __name__ == "__main__":

    username = input('Username: ')
    password = getpass('Password: ')
    device_count = int(input('Number of Devices: '))


    # Threads spun up here
    manager_queue = Queue()
    complete_queue = Queue()
    manager_thread = ManagerThread(manager_queue, complete_queue).start()

    data = parse_input_data()
    complete_device_count = 0

    for host in data:
        if host['complete']: 
            complete_device_count += 1


    for host_index in range(device_count):
        host = data[complete_device_count + host_index]
        
    # Jobs put into queue here
        manager_queue.put({
            "username" : username,
            "password" : password,
            "hostname" : host['hostname'],
            "index" : complete_device_count + host_index,
            "device_type" : "cisco_ios_telnet",
            "additional_data" : host['additional_data']
        })

    for host in range(device_count):
        completed_job = complete_queue.get()
        data[completed_job['index']]['complete'] = True
        print(completed_job["hostname"])
    
    write_file(data)