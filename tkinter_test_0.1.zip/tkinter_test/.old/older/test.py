import re
from tkinter import ttk
import tkinter as tk

test_data = [
    {
        'selected' : True,
        'hostname' : 'man4-sw990.ukfast.net',
        'status' : 'complete',
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw991.ukfast.net',
        'status' : 'complete'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw992.ukfast.net',
        'status' : 'config error'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw993.ukfast.net',
        'status' : 'program error'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw994.ukfast.net',
        'status' : 'running'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw99sss5.ukfast.net',
        'status' : 'running'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw996.ukfast.net',
        'status' : 'running'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw997.ukfast.net',
        'status' : 'running'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw998.ukfast.net',
        'status' : 'running'
    },
    {
        'selected' : False,
        'hostname' : 'man4-sw999.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw990.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw991.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw992.ukfast.net',
        'status' : 'unreachable'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw993.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw994.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw995.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw996.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw997.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw998.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : False,
        'hostname' : 'man4-sw999.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw990.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw991.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw992.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw993.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw994.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw995.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw996.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw997.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : True,
        'hostname' : 'man4-sw998.ukfast.net',
        'status' : 'idle'
    },
    {
        'selected' : False,
        'hostname' : 'man4-sw999.ukfast.net',
        'status' : 'idle'
    }
]


class JobList(tk.Canvas):
    def __init__(self, parent):
        super().__init__(parent)
        self.scrollbar = tk.Scrollbar(parent, orient="vertical")
        self.scrollbar.pack(side="right", fill="y")
        self.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.yview)
        
        self.frame = tk.Frame(self)
        
        self.pack(side="left", fill="both", expand=True)
        self.create_window(0, 0, window=self.frame, anchor='nw')
        
        self.bind("<MouseWheel>", self._on_mousewheel)
        self.bind('<Enter>', self._bound_to_mousewheel)
        self.bind('<Leave>', self._unbound_to_mousewheel)
        
        self.cells = []
        self.all_ticked = False
        self.load_images()
        
        self.create_headers()
        self.load_data(test_data)
        
        parent.update()
        self.config(scrollregion=self.bbox("all"))

    def _bound_to_mousewheel(self, event):
        self.bind_all("<MouseWheel>", self._on_mousewheel)

    def _unbound_to_mousewheel(self, event):
        self.unbind_all("<MouseWheel>")

    def _on_mousewheel(self, event):
        self.yview_scroll(int(-1*(event.delta/120)), "units")
    
    def _highlight_cell(self, event):
        cell = event.widget
        print(cell.grid_info())
        cell.configure(bg="lightblue")
    
    def _unhighlight_cell(self, event):
        cell = event.widget
        cell.configure(bg="#F0F0F0")
    
    def _highlight_row(self, event):
        frame = event.widget
        for cell in frame.children:
            frame.children[cell].configure(bg="lightblue")
    
    def _unhighlight_row(self, event):
        frame = event.widget
        for cell in frame.children:
            frame.children[cell].configure(bg="#F0F0F0")
    

    def load_data(self, data):
        self.create_headers()
        for n, line in enumerate(data, 1):
            
            line_frame = tk.Frame(self.frame)#, relief="solid", bd=1)
            line_frame.grid(row=n, column=0, ipadx=3, columnspan=4, sticky="nesw")
            line_frame.bind("<Enter>", self._highlight_row)
            line_frame.bind("<Leave>", self._unhighlight_row)

            line_frame.grid_columnconfigure(4, weight=1)

            check_button = tk.Checkbutton(line_frame)#, borderwidth=1, relief="raised")
            check_button.grid(row=0, column=0, sticky="nesw")
            
            hostname = tk.Label(line_frame, text=line['hostname'])#, borderwidth=1, relief="raised")
            hostname.grid(row=0, column=1, ipadx=3, sticky="nesw")
            
            status_icon = tk.Label(line_frame, image=self.status_images[line['status']])#, borderwidth=1, relief="raised")
            status_icon.grid(row=0, column=3, ipadx=3, sticky="nesw")
            
            status = tk.Label(line_frame, text=line['status'].capitalize(), anchor="w")#, borderwidth=1, relief="raised")
            status.grid(row=0, column=4, ipadx=3, sticky="nesw")
            
            self.cells.append((check_button, hostname, status_icon, status, line_frame))
    
    def check_all_rows(self):
        if self.all_ticked:
            for cell in self.cells:
                cell[0].deselect()
        else:

            for cell in self.cells:
                cell[0].select()
        self.all_ticked = not self.all_ticked
                
    
    def create_headers(self):

        self.frame.grid_columnconfigure(1, weight=1)
        self.frame.grid_columnconfigure(2, weight=1)
        self.frame.grid_columnconfigure(3, weight=1)

        self.check_all_button = tk.Checkbutton(self.frame, command=self.check_all_rows)#, borderwidth=1, relief="raised")
        self.check_all_button.grid(row=0, column=0, sticky="nesw")
        
        self.hostname_header = tk.Label(self.frame, text="Hostname")#, borderwidth=1, relief="raised")
        self.hostname_header.grid(row=0, column=1, sticky="nesw")
        
        self.status_header = tk.Label(self.frame, text="Status")#, borderwidth=1, relief="raised")
        self.status_header.grid(row=0, column=2, columnspan=3, sticky="nesw")
        

root = tk.Tk()
window = tk.Frame(root, bg="red", width=100)
window1 = tk.Frame(root, bg="blue")
window.place(relheight=1, relwidth=1)
window1.place(relheight=1, relwidth=1)
jl = JobList(window)
window.grid(row=0, column=0)
window1.grid(row=0, column=1)

tk.mainloop()
    
"""


root=tk.Tk()

vscrollbar = tk.Scrollbar(root)

c= tk.Canvas(root,background = "#D2D2D2",yscrollcommand=vscrollbar.set)

vscrollbar.config(command=c.yview)
vscrollbar.pack(side=tk.LEFT, fill=tk.Y) 

f=tk.Frame(c) #Create the frame which will hold the widgets

c.pack(side="left", fill="both", expand=True)

#Updated the window creation
c.create_window(0,0,window=f, anchor='nw')

#Added more content here to activate the scroll
for i in range(100):
    tk.Label(f,wraplength=350 ,text=r"Det er en kendsgerning, at man bliver distraheret af læsbart indhold på en side, når man betragter dens websider, som stadig er på udviklingsstadiet. Der har været et utal af websider, som stadig er på udviklingsstadiet. Der har været et utal af variationer, som er opstået enten på grund af fejl og andre gange med vilje (som blandt andet et resultat af humor).").pack()
    tk.Button(f,text="anytext").pack()

#Removed the frame packing
#f.pack()

#Updated the screen before calculating the scrollregion
root.update()
c.config(scrollregion=c.bbox("all"))

root.mainloop()







root = Tk()

v = PhotoImage(file='./res/circle-red-16.png')

# header
b = Label(root, text="Ip")
b.grid(row=0, column=0)
b = Label(root, text="port")
b.grid(row=0, column=1)
b = Label(root, text="")
b.grid(row=0, column=2)

lista = [["800","127.1.1.",v]]

height = 2
width = 3
for i in range(height-1): #Rows
    b1 = Label(root, text=lista[i][0])
    b1.grid(row=i+1, column=0)
    b2 = Label(root, text=lista[i][1])
    b2.grid(row=i+1, column=1)
    b3 = Label(root, image=lista[i][2])
    b3.grid(row=i+1, column=2)

mainloop()
"""