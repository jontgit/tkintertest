
class Script():
    def __init__(self, remote_connection):
        self.remote_connection = remote_connection
        self.title = "Backup ACLs"
        self.description = ""
        self.device = ""
        self.base_script = """import re
acls = send_command("show access-lists Vty_Access").split('\n')
acl_present = False
deny_number = ""
if "Extended IP access list Vty_Access" in acls:
	acl_present = True
	for acl_line in acls:
		if re.match("    (\d+) deny", acl_line):
			deny_number = re.findall("    (\d+) deny", acl_line)[0]
			print(deny_number)
		
if not acl_present:
    set_status("ACL Missing", "warning")

else:
    send_command("configure terminal")
    send_command("ip access-list extended Vty_Access")
    send_command(f"{int(deny_number)-5} permit ip 10.255.252.0 0.0.1.255 any")
    send_command("end")
    send_command("write")

return_data = acl_present
"""

    def run(self):
        import re
        acls = self.remote_connection.send_command("show access-lists Vty_Access").split('\n')
        yield
        acl_present = False
        deny_number = ""
        if "Extended IP access list Vty_Access" in acls:
            acl_present = True
            for acl_line in acls:
                if re.match("    (\d+) deny", acl_line):
                    deny_number = re.findall("    (\d+) deny", acl_line)[0]
                    print(deny_number)
                
        if not acl_present:
            self.remote_connection.set_status("ACL Missing", "warning")
            yield
        
        else:
            self.remote_connection.send_command("configure terminal")
            yield
            self.remote_connection.send_command("ip access-list extended Vty_Access")
            yield
            self.remote_connection.send_command(f"{int(deny_number)-5} permit ip 10.255.252.0 0.0.1.255 any")
            yield
            self.remote_connection.send_command("end")
            yield
            self.remote_connection.send_command("write")
            yield
        
        return_data = acl_present
        


        vars = locals()
        if "return_data" in vars.keys():
            return vars["return_data"]
        