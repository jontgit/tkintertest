
class Script():
    def __init__(self, remote_connection):
        self.remote_connection = remote_connection
        self.title = "Check Failover"
        self.description = "Gets all psks on a firewall and returns them"
        self.device = "Cisco ASA"
        self.base_script = """import re
failover = send_command("show failover")

if re.search("This host: Primary", failover):
    set_status("Active", "complete")
else:
    set_status("Passive", "complete")

return_data = failover



"""

    def run(self):
        import re
        failover = self.remote_connection.send_command("show failover")
        
        if re.search("This host: Primary", failover):
            self.remote_connection.set_status("Active", "complete")
        else:
            self.remote_connection.set_status("Passive", "complete")
        
        return_data = failover
        
        
        
        


        vars = locals()
        if "return_data" in vars.keys():
            return vars["return_data"]
        