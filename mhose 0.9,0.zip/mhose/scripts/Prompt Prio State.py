
class Script():
    def __init__(self, remote_connection):
        self.remote_connection = remote_connection
        self.title = "Prompt Prio State"
        self.description = ""
        self.device = ""
        self.base_script = """
send_command("conf t")
send_command("prompt hostname")
send_command("end")
send_command("wr")






"""

    def run(self):
        
        self.remote_connection.send_command("conf t")
        yield
        self.remote_connection.send_command("prompt hostname")
        yield
        self.remote_connection.send_command("end")
        yield
        self.remote_connection.send_command("wr")
        yield
        
        
        
        
        
        
        


        vars = locals()
        if "return_data" in vars.keys():
            return vars["return_data"]
        